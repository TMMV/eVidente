# bower-angular-translate

angular-translate bower package

### Installation

````
$ bower install angular-translate
````
