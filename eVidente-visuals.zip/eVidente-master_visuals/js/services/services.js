'use strict';

/* Services */
angular.module('eVidente.services')
    .factory('Servicos', [
        function() {
            var variavel = "";
            return {
                funcao: function(){
                    return "";
                }
            }
        }
    ]);